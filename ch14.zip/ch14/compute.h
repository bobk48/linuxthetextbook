/* Declaration/Prototype of the "compute" function */
double compute(double, double);
