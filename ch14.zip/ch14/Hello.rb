#!/usr/bin/ruby
# The Hello World program in Ruby

puts "Hello, World!"
