// My first Java program
public class Hello {
    public static void main (String[] args) {
        System.out.println ("Hello, World!");
        System.exit (0); 
    }
}
