/* Declaration/Prototype of the "input" function */
double input (char *);
