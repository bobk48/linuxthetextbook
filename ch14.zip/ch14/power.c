#include <stdio.h>
#include <math.h>

int main()
{
	float	x,y;

	printf ("The program takes x and y from stdin and displays x^y.\n"); 
	printf ("Enter integer x: ");
	scanf	("%f", &x);
	printf ("Enter integer y: "); 
	scanf	("%f", &y);
	printf ("x^y is: %6.3f\n", pow((double)x,(double)y));
	return(0);
}
