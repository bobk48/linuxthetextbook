#include <pthread.h>
#include <stdio.h>
#include <unistd.h>

void* thread (void* arg)
{
    printf("Child thread PID is %d\n", (int) getpid());
    for (;;) ;
    return NULL;
}

int main(void)
{
    pthread_t tid;

    printf("Main thread PID is %d\n", (int) getpid());
    pthread_create(&tid, NULL, &thread, NULL);
    /* Spin forever */
    for (;;) ;
    return 0;
}
