void main(void)
{
	printf("Child's PID = %d\n", getpid());
	printf("Parent's PID = %d\n", getppid());
}
